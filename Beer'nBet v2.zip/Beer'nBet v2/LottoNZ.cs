﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace Beer_nBet
{
    class LottoNZ : Lotto
    {
        public LottoNZ()
        {
            numArray = new int[7];
        }
        public override void BubbleSort()
        {
            int temp;
            for (int i = 0; i < numArray.Length - 2; i++) //this will loop the same number of times there are elements in array
            {
                for (int j = 0; j < numArray.Length - 2; j++)
                {
                    if (numArray[j] > numArray[j + 1])
                    {
                        temp = numArray[j];
                        numArray[j] = numArray[j + 1];
                        numArray[j + 1] = temp;
                    }
                    //else nothing happens
                }
            }
        }

        //displays numbers of ticket
        public override void PrintNumbers(TextBlock textBlock)
        {
            //displays all items in numArray
            for (int i = 0; i < numArray.Length - 1; i++)
            {
                if (numArray[i] < 10)
                {
                    textBlock.Text = textBlock.Text + numArray[i].ToString("00") + " ";
                }
                else
                {
                    textBlock.Text = textBlock.Text + numArray[i] + " ";
                }

            }
            if (numArray[6] < 10)
            {
                textBlock.Text = textBlock.Text + numArray[6].ToString("00") + " ";
            }
            else
            {
                textBlock.Text = textBlock.Text + "   " + numArray[6] + " ";
            }
        }
    }
}
