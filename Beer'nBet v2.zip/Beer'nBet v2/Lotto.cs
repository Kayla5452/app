﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace Beer_nBet
{
    class Lotto
    {
        //instance variables
        public int[] numArray;
        private Random random;

        //sets up object for class
        public Lotto()
        {
            numArray = new int[6];
            random = new Random(DateTime.Now.Millisecond);
        }

        //sets all numbers in array to 0
        public void SetNumbersToZero()
        {
            for (int i = 0; i < numArray.Length; i++)
            {
                numArray[i] = 0;
            }
        }

        //generates numbers for ticket
        public void GenerateNumbers()
        {
            int numArrayHold;

            //assigns a numbers into numArray
            //stole from here https://stackoverflow.com/questions/35973361/fill-array-with-random-but-unique-numbers-in-c-sharp for unique number generation
            for (int i = 0; i < numArray.Length; i++)
            {
                
                numArrayHold = 0;
                while (true)
                {
                    numArrayHold = random.Next(1, 50);
                    if (!Contains(numArray, numArrayHold)) break;
                }
                numArray[i] = numArrayHold;
                

            }
            BubbleSort();
        }
        private bool Contains(int[] array, int value)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == value) return true;

            }
            return false;
        }

        public virtual void BubbleSort()
        {
            int temp;
            for (int i = 0; i < numArray.Length - 1; i++) //this will loop the same number of times there are elements in array
            {
                for (int j = 0; j < numArray.Length - 1; j++)
                {
                    if (numArray[j] > numArray[j + 1])
                    {
                        temp = numArray[j];
                        numArray[j] = numArray[j + 1];
                        numArray[j + 1] = temp;
                    }
                    //else nothing happens
                }
            }
        }

        //displays numbers of ticket
        public virtual void PrintNumbers(TextBlock textBlock)
        {
            //displays all items in numArray
            for (int i = 0; i < numArray.Length; i++)
            {
                if (numArray[i] < 10)
                {
                    textBlock.Text = textBlock.Text + numArray[i].ToString("00") + " ";
                }
                else
                {
                    textBlock.Text = textBlock.Text + numArray[i] + " ";
                }
                
            }
        }
    }
}
