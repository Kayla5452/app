﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml.Media.Imaging;
using Windows.Media.SpeechSynthesis;
using Windows.UI.Popups;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Beer_nBet
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    
    
    public sealed partial class Drinks : Page
    {
        SpeechSynthesizer reader = new SpeechSynthesizer();

        //dictionary of drinks
        Dictionary<string, Drink> drinkDictionary = new Dictionary<string, Drink>()
        {
            {"Cosmopolitan", new Drink() { Name = "Cosmopolitan",ImageName="Cosmopolitan.png",Recipe = "1.5 ounces of citrus vodka, 1 ounce of Cointreau, half an ounce of lime juice and a quarter of an ounce of cranberry juice.", Mix="Put all the ingredients in a shaker with ice and shake. Strain into a martini glass and garnish with a lime wheel or zest."} },
            {"Daiquiri",new Drink() {Name = "Daiquiri",ImageName="Daiquiri.png",Recipe="2 ounces of light rum, 1 ounce of simple syrup and 1 ounces of lime juice.",Mix="Shake ingredients with ice and strain into a cocktail glass. Garnish with a lime wheel."} },
            {"Dark n Stormy", new Drink() {Name = "Dark n Stormy",ImageName="Dark n Stormy.png",Recipe="1.5 ounces of Gosling’s Black Seal Rum and ginger beer to top.", Mix = "Fill a highball glass with ice and add rum and ginger beer. Garnish with lime."} },
            {"French 75", new Drink() {Name="French 75",ImageName="French 75.png",Recipe="2 ounces of gin, 2 dashes of simple syrup, half an ounce of lemon juice and champagne.",Mix="Shake gin, simple syrup, and lemon juice with ice. Strain into a champagne glass. Top with champagne."} },
            {"Gimlet", new Drink() {Name="Gimlet",ImageName="Gimlet.png",Recipe="2 ounces of gin or vodka, three quarters of an ounce of simple syrup, three quarters of an ounce of lime juice.",Mix="Shake ingredients with ice and strain into a cocktail glass."} },
            {"Manhattan", new Drink() {Name="Manhattan",ImageName="Manhattan.png",Recipe="2 ounces of rye whiskey, 1 ounce of sweet vermouth and 2 dashes of Angostura bitters.",Mix="Stir ingredients in a mixing glass with ice. Strain into chilled martini glass or cocktail glass."} },
            {"Margarita", new Drink() {Name="Margarita",ImageName="Margarita.png",Recipe="2 ounces of silver tequila, 1 ounce of Cointreau, 1 ounce of lime juice and salt for the glass rim.",Mix="It should be shaken, then serve over ice in a glass with a salted rim."} },
            {"Martinez", new Drink() {Name="Martinez",ImageName="Martinez.png",Recipe="1.5 ounces of Old Tom gin, 1.5 ounces of sweet vermouth, a quarter of an ounce of Luxardo maraschino liqueur and 2 dashes of Angostura or orange bitters.",Mix="Stir ingredients in a mixing glass with ice. Strain into chilled martini glass or cocktail glass."} },
            {"Martini",new Drink() {Name="Martini",ImageName="Martini.png",Recipe="3 ounces of gin or vodka, half an ounce of dry vermouth and lemon peel or an olive.",Mix="Stir ingredients in a mixing glass with ice. Strain into a chilled martini glass. Squeeze oil from the lemon peel into the glass or garnish with an olive."} },
            {"Mimosa", new Drink() {Name="Mimosa",ImageName="Mimosa.png",Recipe="2.5 ounces of champagne and 2.5 ounces of orange juice.",Mix="Combine equal parts of the ingredients in a champagne flute."} },
            {"Mint Julep", new Drink() {Name="Mint Julep",ImageName="Mint Julep.png",Recipe="2 ounces of bourbon, 8 to 10 mint leaves and a quarter of an ounce of simple syrup.",Mix="Mix-up the mint leaves and simple syrup in a cup. Add bourbon and fill with crushed ice. Stir until the cup is frosted. Fill with more crushed ice. Serve with a straw and a mint sprig garnish."} },
            {"Mojito", new Drink() {Name="Mojito",ImageName="Mojito.png",Recipe="3 mint leaves, 2 ounces of white rum, three quarters of an ounce of lime juice and half an ounce of simple syrup.",Mix="Mix-up mint into a shaker tin, then add ice and all other ingredients. Shake to chill and strain into a highball glass with ice. Top with club soda if desired and garnish with mint."} },
            {"Moscow Mule", new Drink() {Name="Moscow Mule",ImageName="Moscow Mule.png",Recipe="2 ounces of vodka, 4 to 6 ounces of ginger beer and 5 ounces of lime juice.",Mix="Squeeze lime juice into a mug, add two or three ice cubes, pour in the vodka, and fill with cold ginger beer. Stir and serve."} },
            {"Negroni", new Drink() {Name="Negroni",ImageName="Negroni.png",Recipe="1 ounce of gin, 1 ounce of Campari and 1 ounce of sweet vermouth.",Mix="Stir ingredients with ice."}},
            {"Old Fashioned", new Drink() {Name="Old Fashioned",ImageName="Old Fashioned.png",Recipe="2 ounces of bourbon or rye whiskey, 2 dashes of Angostura bitters, 1 sugar cube or 1 tablespoon sugar and an orange twist garnish.",Mix="Put sugar in glass. Cover it with dashes of bitters. Add whiskey and stir until the sugar dissolves. Add ice, stir again, and serve."} },
            {"Paloma", new Drink() {Name="Paloma",ImageName="Paloma.png",Recipe="2 ounces of tequila, half an ounce of lime juice and grapefruit soda to top.",Mix="Add tequila and lime to a salt-rimmed glass filled with ice. Top with grapefruit soda."} },
            {"Pimms Cup", new Drink() {Name="Pimms Cup",ImageName="Pimms Cup.png",Recipe="1.75 ounces of  Pimm's No.1, 5 ounces of lemonade, mint, orange, strawberries and cucumber to garnish.",Mix="Pile all the ingredients in a tall glass, mix, and sip."} },
            {"Pina Colada", new Drink() {Name="Pina Colada",ImageName="Pina Colada.png",Recipe="3 ounces of white rum, 1.5 ounces of coconut cream, 3.5 ounces of pineapple juice, 10 ounces of crushed ice and 1 slice of pineapple.",Mix="Place the crushed ice into a blender and whizz it for 15 seconds. Now add the coconut cream, rum and the pineapple juice. Blend it on medium until you get a smooth, creamy mixture. Pour it into a tall wine glass and garnish the side of the glass with a slice ofpineapple."} },
            {"Sazerac", new Drink() {Name="Sazerac",ImageName="Sazerac.png",Recipe="2 ounces of rye whiskey, half an ounce of simple syrup, 2 dashes of Peychaud's bitters and Absinthe.",Mix="Rinse a chilled glass with absinthe and discard the absinthe. Stir the other ingredients in a mixing glass, strain into the chilled glass, and garnish."} },
            {"Sidecar", new Drink() {Name="Sidecar",ImageName="Sidecar.png",Recipe="2 ounces of VS or VSOP Cognac, 1 ounce of Cointreau, three quarters of an ounce of lemon juice.",Mix="Shake ingredients with ice. Strain into a rocks glass or a cocktail class with a sugar-coated rim."} },
            {"Singapore Sling", new Drink() {Name="Singapore Sling",ImageName="Singapore Sling.png",Recipe="1.5 ounces of Ford’s Gin, a quarter of an ounce of Cherry Herring, a quarter of an ounce of Combier, a quarter of an ounce of Benedictine, 2 ounces  of pineapple juice and a quarter of an ounce of grenadine.",Mix="Add all the ingredients into a shaker over ice. Shake and strain into tiki glass with fresh pebble ice. Garnish with orange peel and macerated cherry."} },
            {"Surfer Girl", new Drink() {Name="Surfer Girl",ImageName="Surfer Girl.png",Recipe="1.5 ounces of Four Pillars Rare Dry Gin, half an ounce of lime juice, half an ounce of honey, 1 ounce of watermelon juice and 5 to 6 basil leaves.",Mix="Combine all ingredients in a shaker over ice. Shake. Strain into a coupe glass and garnish with basil."} },
            {"Whiskey Sour", new Drink() {Name="Whiskey Sour",ImageName="Whiskey Sour.png",Recipe="2 ounces of whiskey, 1 ounce of lemon juice, 1 tablespoon of sugar and 1 egg white optional.",Mix="Combine ingredients in a cocktail shaker and shake. Add ice and shake again. Strain over ice in a rocks glass."} }
        };

        //constructor
        public Drinks()
        {
            this.InitializeComponent();
            ApplicationView.GetForCurrentView().TryResizeView(new Size(App.DeviceScreenWidth, App.DeviceScreenHeight));
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size(App.DeviceMinimumScreenWidth, App.DeviceMinimumScreenHeight));
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            ListBoxDrinks.ItemsSource = drinkDictionary.Keys;

            //visability settings
            gridDrinks.Visibility = Visibility.Visible;
            gridOrder.Visibility = Visibility.Collapsed;
            gridOrderButtons.Visibility = Visibility.Collapsed;
            gridDrinkButtons.Visibility = Visibility.Visible;

            ListBoxDrinks.SelectedIndex = -1;
            listboxOrder.SelectedIndex = -1;
        }

        //navigation
        private void btnNavBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }

        private void btnBackToDrinks_Click(object sender, RoutedEventArgs e)
        {
            gridDrinks.Visibility = Visibility.Visible;
            gridOrder.Visibility = Visibility.Collapsed;
            gridOrderButtons.Visibility = Visibility.Collapsed;
            gridDrinkButtons.Visibility = Visibility.Visible;
        }

        private void btnViewOrder_Click(object sender, RoutedEventArgs e)
        {
            gridDrinks.Visibility = Visibility.Collapsed;
            gridOrder.Visibility = Visibility.Visible;
            gridOrderButtons.Visibility = Visibility.Visible;
            gridDrinkButtons.Visibility = Visibility.Collapsed;
        }


        //Drinks listbox selection change
        private void ListBoxDrinks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListBoxDrinks.SelectedIndex != -1)
            {
                string itemSelected = ListBoxDrinks.SelectedItem.ToString();
                if (drinkDictionary.ContainsKey(itemSelected) == false)
                {
                    txtName.Text = itemSelected + " not found";
                    imgDrink1.Source = new BitmapImage(new Uri("ms-appx:///Assets/Empty Glass.png", UriKind.RelativeOrAbsolute));

                }
                else
                {
                    Drink theDrink = drinkDictionary[itemSelected];
                    txtName.Text = theDrink.Name.ToString();
                    txtRecipe.Text = theDrink.Recipe.ToString();
                    txtMix.Text = theDrink.Mix.ToString();
                    imgDrink1.Source = new BitmapImage(new Uri("ms-appx:///Assets/" + theDrink.ImageName.ToString(), UriKind.RelativeOrAbsolute));

                }
            }
            
        }

        //Drinks text to speech
        private void ListBoxDrinks_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            string Drinkstring = txtName.Text + ". Recipe. " + txtRecipe.Text + ". Mix. " + txtMix.Text;
            Talk(Drinkstring);
        }
        private async void Talk(string message)
        {
            var stream = await reader.SynthesizeTextToStreamAsync(message);
            media.SetSource(stream, stream.ContentType);
            media.Play();
               
        }

        //Add drink to Order listbox
        private async void btnAddDrink_Click(object sender, RoutedEventArgs e)
        {
            if (ListBoxDrinks.SelectedIndex != -1)
            {
                Drink theDrink = drinkDictionary[ListBoxDrinks.SelectedItem.ToString()];
                listboxOrder.Items.Add(theDrink.Name.ToString());
                ContentDialog addDrink = new ContentDialog()
                {
                    Title = "Drink Added",
                    Content = ("Your drink has been added to your order"),
                    CloseButtonText = "Ok"
                };
                await addDrink.ShowAsync();
            }
            else
            {
                ContentDialog placeOrder = new ContentDialog()
                {
                    Title = "Error",
                    Content = ("You have not selected a drink to add to your order"),
                    CloseButtonText = "Ok"
                };
                await placeOrder.ShowAsync();
            }
            ListBoxDrinks.SelectedIndex = -1;


        }

        //Place order
        private async void btnPlace_Click(object sender, RoutedEventArgs e)
        {
            if (listboxOrder.Items.Count == 0)
            {
                ContentDialog placeOrder = new ContentDialog()
                {
                    Title = "Error",
                    Content = ("You have not ordered any drinks"),
                    CloseButtonText = "Ok"
                };
                await placeOrder.ShowAsync();
            }
            else
            {
                ContentDialog placeOrder = new ContentDialog()
                {
                    Title = "Order Placed",
                    Content = ("You have ordered " + listboxOrder.Items.Count +" drinks to your table"),
                    CloseButtonText = "Ok"
                };
                await placeOrder.ShowAsync();
                this.Frame.Navigate(typeof(MainPage));
                this.Frame.Navigate(typeof(Drinks));
            }
        }

        //Remove drink from order listbox
        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            if (listboxOrder.SelectedIndex != -1)
            {
                int index = listboxOrder.SelectedIndex;
                listboxOrder.Items.RemoveAt(index);
                listboxOrder.SelectedIndex = -1;
            }
        }
    }
}
