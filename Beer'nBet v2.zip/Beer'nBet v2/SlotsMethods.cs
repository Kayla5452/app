﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

namespace Beer_nBet
{
    class SlotsMethods
    {
        public void Spin(bool clicked, int wheel, Image img)
        {
            if (clicked == false)
            {
                if (wheel == 1) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/lose7.png", UriKind.RelativeOrAbsolute));
                else if (wheel == 2) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/spade.png", UriKind.RelativeOrAbsolute));
                else if (wheel == 3) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/club.png", UriKind.RelativeOrAbsolute));
                else if (wheel == 4) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/heart.png", UriKind.RelativeOrAbsolute));
                else if (wheel == 5) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/diamond.png", UriKind.RelativeOrAbsolute));
                else img.Source = new BitmapImage(new Uri("ms-appx:///Assets/win.png", UriKind.RelativeOrAbsolute));
            }
        }
        public int Winnings(int wheel1, int wheel2, int wheel3,Image img)
        {

            // Six – six – six: Win $60 display win image.
            if ((wheel1 == 6) && (wheel2 == 6) && (wheel3 == 6))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 60;
            }
            // Five – five – five: Win $50 display win image.
            if ((wheel1 == 5) && (wheel2 == 5) && (wheel3 == 5))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png", UriKind.RelativeOrAbsolute));
                return 50;
            }
            // Four – four – four: Win $40 display win image.
            if ((wheel1 == 4) && (wheel2 == 4) && (wheel3 == 4))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 40;
            }
            // Three – three – three: Win $30 display win image.
            if ((wheel1 == 3) && (wheel2 == 3) && (wheel3 == 3))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 30;
            }
            // Two – two – two: Win $20 display win image.
            if ((wheel1 == 2) && (wheel2 == 2) && (wheel3 == 2))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 20;
            }


            // Five – five – six: Win $10 display win image.
            if (((wheel1 == 5) && (wheel2 == 5) && (wheel3 == 6)) | ((wheel1 == 5) && (wheel2 == 6) && (wheel3 == 5)) | ((wheel1 == 6) && (wheel2 == 5) && (wheel3 == 5)))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 10;
            }
            // Four – four – six: Win $8 display win image.
            if (((wheel1 == 4) && (wheel2 == 4) && (wheel3 == 6))| ((wheel1 == 4) && (wheel2 == 6) && (wheel3 == 4))| ((wheel1 == 6) && (wheel2 == 4) && (wheel3 == 4)))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 8;
            }
            // Three – three – six: Win $6 display win image.
            if (((wheel1 == 3) && (wheel2 == 3) && (wheel3 == 6))| ((wheel1 == 3) && (wheel2 == 6) && (wheel3 == 3))| ((wheel1 == 6) && (wheel2 == 3) && (wheel3 == 3)))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 6;
            }
            // Two – two – six: Win $4 display win image.
            if (((wheel1 == 2) && (wheel2 == 2) && (wheel3 == 6))| ((wheel1 == 2) && (wheel2 == 6) && (wheel3 == 2))| ((wheel1 == 6) && (wheel2 == 2) && (wheel3 == 2)))
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/jackpot.png",
                                                      UriKind.RelativeOrAbsolute));
                return 4;
            }
            // Lose $2 for every one rolled on a wheel and display lose image.
            if (wheel1 == 1)
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/lose.png",
                                                      UriKind.RelativeOrAbsolute));
                return -2;
            }
            // Lose $2 for every one rolled on a wheel and display lose image.
            if (wheel2 == 1)
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/lose.png",
                                                      UriKind.RelativeOrAbsolute));
                return -2;
            }
            // Lose $2 for every one rolled on a wheel and display lose image.
            if (wheel3 == 1)
            {
                img.Source = new BitmapImage(new Uri("ms-appx:///Assets/lose.png",
                                                      UriKind.RelativeOrAbsolute));
                return -2;
            }

            return 0;
        }
        public bool ClickHold(bool clicked, Image img)
        {
            if (clicked == false)
            {
                img.Opacity = 0.5f;
                return true;
            }
            else
            {
                img.Opacity = 1f;
                return false;
            }
        }
        public int CheckHold(bool hold)
        {
            if (hold == true)
            {
                return 20;
            }
            else
            {
                return 0;
            }
            
        }
        public bool RemoveHold(Image img)
        {
            img.Opacity = 1f;
            return false;
        }
        public void DisplayCash(TextBox txt, int dollars)
        {
            txt.Text = "$" + dollars;
        }
    }
}
