﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml.Media.Imaging;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Beer_nBet
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Slots : Page
    {
        //object of class
        SlotsMethods methods = new SlotsMethods();

        //instance variables
        Random number;
        int dollars;
        int wheel1, wheel2, wheel3;
        bool wheel1Clicked = false, wheel2Clicked = false, wheel3Clicked = false;
        bool loadUp = true;

        //onload "Mainpage"
        public Slots()
        {
            number = new Random(DateTime.Now.Millisecond);

            //onload default stuff
            this.InitializeComponent();
            ApplicationView.GetForCurrentView().TryResizeView(new Size(App.DeviceScreenWidth, App.DeviceScreenHeight));
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size(App.DeviceMinimumScreenWidth, App.DeviceMinimumScreenHeight));
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;

            //slots on load
            imgWinLose.Source = new BitmapImage(new Uri("ms-appx:///Assets/slotsDefault.png", UriKind.RelativeOrAbsolute));
            imgWheel1.Source = new BitmapImage(new Uri("ms-appx:///Assets/heart.png", UriKind.RelativeOrAbsolute));
            imgWheel2.Source = new BitmapImage(new Uri("ms-appx:///Assets/heart.png", UriKind.RelativeOrAbsolute));
            imgWheel3.Source = new BitmapImage(new Uri("ms-appx:///Assets/heart.png", UriKind.RelativeOrAbsolute));
            btnSpin.Visibility = Visibility.Collapsed;
            if (loadUp == true)
            {
                wheel1Clicked = false;
                wheel2Clicked = false;
                wheel3Clicked = false;
                loadUp = false;
            }

        }

        //wheel 1 hold
        private void imgWheel1_Tapped(object sender, TappedRoutedEventArgs e)
        {
            wheel1Clicked = methods.ClickHold(wheel1Clicked, imgWheel1);
        }

        //wheel 2 hold
        private void imgWheel2_Tapped(object sender, TappedRoutedEventArgs e)
        {
            wheel2Clicked = methods.ClickHold(wheel2Clicked, imgWheel2);
        }

        //wheel 3 hold
        private void imgWheel3_Tapped(object sender, TappedRoutedEventArgs e)
        {
            wheel3Clicked = methods.ClickHold(wheel3Clicked, imgWheel3);
        }


        //nav
        private void btnNavBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }


        //add cash
        private void btnAddCash_Click(object sender, RoutedEventArgs e)
        {
            dollars += 10;
            methods.DisplayCash(txtCashAmount, dollars);

            if (dollars > 0) { btnSpin.Visibility = Visibility.Visible; }
        }

        //spin button
        private void btnSpin_Click(object sender, RoutedEventArgs e)
        {

            //random num gen
            imgWinLose.Visibility = Visibility.Visible;
            imgWinLose.Source = new BitmapImage(new Uri("ms-appx:///Assets/slotsDefault.png",
                                                      UriKind.RelativeOrAbsolute));
            wheel1 = number.Next(1, 7); //random num between 1 & 6
            wheel2 = number.Next(1, 7); //random num
            wheel3 = number.Next(1, 7); //random num

            //cost to play and hold
            dollars--;

            //checks for an active hold
            dollars -= methods.CheckHold(wheel1Clicked);
            dollars -= methods.CheckHold(wheel2Clicked);
            dollars -= methods.CheckHold(wheel3Clicked);

            //spins the wheels
            methods.Spin(wheel1Clicked, wheel1, imgWheel1);
            methods.Spin(wheel2Clicked, wheel2, imgWheel2);
            methods.Spin(wheel3Clicked, wheel3, imgWheel3);

            //winnings calculated
            dollars += methods.Winnings(wheel1, wheel2, wheel3, imgWinLose);

            //turn off holds for each spin

            wheel1Clicked = methods.RemoveHold(imgWheel1);
            wheel2Clicked = methods.RemoveHold(imgWheel2);
            wheel3Clicked = methods.RemoveHold(imgWheel3);

            //check balance
            if (dollars <= 0)
            {
                btnSpin.Visibility = Visibility.Collapsed;
                dollars = 0;
            }

            //display balance
            methods.DisplayCash(txtCashAmount, dollars);
        }
    }
}
