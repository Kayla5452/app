﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;
using Windows.Media.SpeechSynthesis;
using Windows.UI.Popups;

namespace Beer_nBet
{
    class DiceMethods
    {
        //check if dice is held
        public bool ClickHold(bool clicked, Image img)
        {
            if (clicked == false)
            {
                img.Opacity = 0.5f;
                return true;
            }
            else
            {
                img.Opacity = 1f;
                return false;
            }
        }

        //roll dice
        public void Roll(bool clicked, int dice, Image img)
        {
            if (clicked == false)
            {
                if (dice == 1) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
                else if (dice == 2) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice2.png", UriKind.RelativeOrAbsolute));
                else if (dice == 3) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice3.png", UriKind.RelativeOrAbsolute));
                else if (dice == 4) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice4.png", UriKind.RelativeOrAbsolute));
                else if (dice == 5) img.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice5.png", UriKind.RelativeOrAbsolute));
                else img.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice6.png", UriKind.RelativeOrAbsolute));
            }
        }
        
        //get total of all dice rolled
        public int getTotal(int dice1, int dice2, int dice3, int dice4, int dice5)
        {
            return (dice1 + dice2 + dice3 + dice4 + dice5);
        }

        //determine winner of round
        public async void Winner(int p1Total, int p2Total,Button btn)
        {
            //player 1 wins
            if (p1Total>p2Total)
            {
                ContentDialog winner = new ContentDialog()
                {
                    Title = "Winner",
                    Content = ("Player 1 scored " + p1Total + "\nPlayer 2 scored " + p2Total + "\nThe Winner is Player 1"),
                    CloseButtonText = "Ok"
                };
                await winner.ShowAsync();
            }
            //player 2 wins
            else if (p2Total>p1Total)
            {
                ContentDialog winner = new ContentDialog()
                {
                    Title = "Winner",
                    Content = ("Player 1 scored " + p1Total + "\nPlayer 2 scored " + p2Total + "\nThe Winner is Player 2"),
                    CloseButtonText = "Ok"
                };
                await winner.ShowAsync();
            }
            //tie
            else
            {
                ContentDialog winner = new ContentDialog()
                {
                    Title = "Tie",
                    Content = ("Player 1 scored " + p1Total + "\nPlayer 2 scored " + p2Total + "\nIt's a tie"),
                    CloseButtonText = "Ok"
                };
                await winner.ShowAsync();
            }
            //play again button now enabled
            btn.IsEnabled = true;
            
        }
    }
}
