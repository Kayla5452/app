﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Windows.UI.Xaml.Media.Imaging;

using Windows.UI.ViewManagement;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Beer_nBet
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Dice : Page
    {
        //instance variables
        DiceMethods methods = new DiceMethods();
        Random random;
        bool restart = true;
        bool dice1Clicked = false, dice2Clicked = false, dice3Clicked = false, dice4Clicked = false, dice5Clicked = false, dice6Clicked = false, dice7Clicked = false, dice8Clicked = false, dice9Clicked = false, dice10Clicked = false;
        int p1Rolls = 0, p2Rolls = 0;
        int dice1, dice2, dice3, dice4, dice5, dice6, dice7, dice8, dice9, dice10;
        int player1Total = 0, player2Total = 0;

        //hides instructions and shows game
        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            gridDiceGame.Visibility = Visibility.Visible;
            gridInstructions.Visibility = Visibility.Collapsed;
            btnInstructions.IsEnabled = true;
        }

        //show instructions on screen
        private void btnInstructions_Click(object sender, RoutedEventArgs e)
        {
            gridDiceGame.Visibility = Visibility.Collapsed;
            gridInstructions.Visibility = Visibility.Visible;
            btnInstructions.IsEnabled = false;
            InstructionsTxtBlock.Text = "Each player gets three rolls to try and get the highest total.\n";
            InstructionsTxtBlock.Text += "All of each player's dice are added together to give their total.\n";
            InstructionsTxtBlock.Text += "Rolls can be done in any order, either one after the other, or all of one player's rolls at once.\n";
            InstructionsTxtBlock.Text += "Player's can click on dice they want to keep for the next roll";

        }

        //restart game by navigating to main page and back
        private void btnRestart_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
            this.Frame.Navigate(typeof(Dice));
        }


        //constructor
        public Dice()
        {

            random = new Random(DateTime.Now.Millisecond);
            this.InitializeComponent();
            ApplicationView.GetForCurrentView().TryResizeView(new Size(App.DeviceScreenWidth, App.DeviceScreenHeight));
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size(App.DeviceMinimumScreenWidth, App.DeviceMinimumScreenHeight));
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;

            //on load
            gridInstructions.Visibility = Visibility.Collapsed;

            imgDice1.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice2.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice3.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice4.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice5.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice6.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice7.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice8.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice9.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            imgDice10.Source = new BitmapImage(new Uri("ms-appx:///Assets/dice1.png", UriKind.RelativeOrAbsolute));
            
            //makes sure all dice are not held
            if (restart == true)
            {
                dice1Clicked = false;
                dice2Clicked = false;
                dice3Clicked = false;
                dice1Clicked = false;
                dice5Clicked = false;
                dice6Clicked = false;
                dice7Clicked = false;
                dice8Clicked = false;
                dice9Clicked = false;
                dice10Clicked = false;
                restart = false;
            }

            btnRestart.IsEnabled = false;

        }
        
        //back nav
        private void btnNavBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }

        //p1 roll
        private void btnRollPlayer1_Click(object sender, RoutedEventArgs e)
        {
            if (p1Rolls <= 3)
            {
                //gen ran number
                dice1 = random.Next(1, 7);
                dice2 = random.Next(1, 7);
                dice3 = random.Next(1, 7);
                dice4 = random.Next(1, 7);
                dice5 = random.Next(1, 7);

                //roll dice
                methods.Roll(dice1Clicked, dice1, imgDice1);
                methods.Roll(dice2Clicked, dice2, imgDice2);
                methods.Roll(dice3Clicked, dice3, imgDice3);
                methods.Roll(dice4Clicked, dice4, imgDice4);
                methods.Roll(dice5Clicked, dice5, imgDice5);

                //get total
                player1Total = methods.getTotal(dice1, dice2, dice3, dice4, dice5);

                //check for rolls
                p1Rolls++;
                if (p1Rolls == 3)
                {
                    //removed holds on all dice
                    btnRollPlayer1.IsEnabled = false;
                    dice1Clicked = methods.ClickHold(true, imgDice1);
                    dice2Clicked = methods.ClickHold(true, imgDice2); 
                    dice3Clicked = methods.ClickHold(true, imgDice3);
                    dice1Clicked = methods.ClickHold(true, imgDice4);
                    dice5Clicked = methods.ClickHold(true, imgDice5);
                    //only checks to compare scores if both players have had 3 rolls
                    if (p2Rolls==3)
                    {
                        methods.Winner(player1Total, player2Total, btnRestart);
                    }
                }
            }
        }

        //p2 roll
        private void btnRollPlayer2_Click(object sender, RoutedEventArgs e)
        {
            if (p2Rolls <= 3)
            {
                //gen ran number
                dice6 = random.Next(1, 7);
                dice7 = random.Next(1, 7);
                dice8 = random.Next(1, 7);
                dice9 = random.Next(1, 7);
                dice10 = random.Next(1, 7);

                //roll dice
                methods.Roll(dice6Clicked, dice6, imgDice6);
                methods.Roll(dice7Clicked, dice7, imgDice7);
                methods.Roll(dice8Clicked, dice8, imgDice8);
                methods.Roll(dice9Clicked, dice9, imgDice9);
                methods.Roll(dice10Clicked, dice10, imgDice10);

                //get total
                player2Total = methods.getTotal(dice6, dice7, dice8, dice9, dice10);

                //check for rolls
                p2Rolls++;
                if (p2Rolls == 3)
                {
                    btnRollPlayer2.IsEnabled = false;
                    dice6Clicked = methods.ClickHold(true, imgDice6);
                    dice7Clicked = methods.ClickHold(true, imgDice7);
                    dice8Clicked = methods.ClickHold(true, imgDice8);
                    dice9Clicked = methods.ClickHold(true, imgDice9);
                    dice10Clicked = methods.ClickHold(true, imgDice10);
                    if (p1Rolls == 3)
                    {
                        methods.Winner(player1Total, player2Total,btnRestart);
                    }
                }
            }
        }

        //img holds p2
        private void imgDice6_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice6Clicked = methods.ClickHold(dice6Clicked, imgDice6);
        }

        private void imgDice7_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice7Clicked = methods.ClickHold(dice7Clicked, imgDice7);
        }

        private void imgDice8_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice8Clicked = methods.ClickHold(dice8Clicked, imgDice8);
        }

        private void imgDice9_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice9Clicked = methods.ClickHold(dice9Clicked, imgDice9);
        }

        private void imgDice10_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice10Clicked = methods.ClickHold(dice10Clicked, imgDice10);
        }

        //img holds p1
        private void imgDice5_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice5Clicked = methods.ClickHold(dice5Clicked, imgDice5);
        }

        private void imgDice4_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice4Clicked = methods.ClickHold(dice4Clicked, imgDice4);
        }

        private void imgDice3_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice3Clicked = methods.ClickHold(dice3Clicked, imgDice3);
        }

        private void imgDice2_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice2Clicked = methods.ClickHold(dice2Clicked, imgDice2);
        }

        private void imgDice1_Tapped(object sender, TappedRoutedEventArgs e)
        {
            dice1Clicked = methods.ClickHold(dice1Clicked, imgDice1);
        }

    }
}
