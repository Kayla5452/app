﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.ViewManagement;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Beer_nBet
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            ApplicationView.GetForCurrentView().TryResizeView(new Size(App.DeviceScreenWidth, App.DeviceScreenHeight));
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size(App.DeviceMinimumScreenWidth, App.DeviceMinimumScreenHeight));
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
        }

        private void btnLotteryNavigate_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Lottery));
        }

        private void btnDiceNavigate_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Dice));
        }

        private void btnSlotsNavigate_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Slots));
        }

        private void btnPredictionNavigate_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Prediction));
        }

        private void btnDrinksNavigate_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Drinks));
        }
    }
}
