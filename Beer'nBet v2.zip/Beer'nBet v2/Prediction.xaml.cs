﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.ViewManagement;
using Windows.Media.SpeechSynthesis;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Beer_nBet
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Prediction : Page
    {
        SpeechSynthesizer reader = new SpeechSynthesizer();

        string[] timeArray = { "thirty minutes", "an hour", "two hours", "three hours", "four hours", "eight hours", "twelve", "a day", "a week" };
        string[] aspectArray = { "finances", "love life", "career prospects", "travel plans", "relationships" };
        string[] effectArray = { "fall apart", "exceed you expectation", "become awkward in an unexpected way", "become manageable", "become spectacular", "come to a positive outcome" };
        string[] personArray = { "man", "boy", "woman", "girl", "dog", "bird", "hedgehog", "singer", "relative" };
        string[] featureArray = { "pink hair", "a broken golden chain", "scary eyes", "long blonde nose hair", "very red lips", "silver feet" };
        string[] drinkArray = { "Gimlet", "Pina Colada", "Cosmopolitan", "Manhattan", "Margarita", "Martini" };

        public Prediction()
        {
            this.InitializeComponent();
            ApplicationView.GetForCurrentView().TryResizeView(new Size(App.DeviceScreenWidth, App.DeviceScreenHeight));
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size(App.DeviceMinimumScreenWidth, App.DeviceMinimumScreenHeight));
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
        }

        private void btnNavBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }

        private void btnPrediction_Click(object sender, RoutedEventArgs e)
        {
            Random rng = new Random();
            string text = "Over a period of " + timeArray[rng.Next(0, timeArray.Length)] + " your " + aspectArray[rng.Next(0, aspectArray.Length)] + " will " + effectArray[rng.Next(0, effectArray.Length)] + ". This will come to pass after you meet a "+ personArray[rng.Next(0, personArray.Length)] + " with " + featureArray[rng.Next(0, featureArray.Length)] + " who recommends a " + drinkArray[rng.Next(0, drinkArray.Length)] + " to drink.";
            txtPrediction.Text = text;
            Talk(text);

        }
        private async void Talk(string message)
        {
            var stream = await reader.SynthesizeTextToStreamAsync(message);
            media.SetSource(stream, stream.ContentType);
            media.Play();
        }
    }
}
