﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.ViewManagement;
using System.Windows.Input;
using System.Windows;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Beer_nBet
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Lottery : Page
    {
        public Lottery()
        {
            this.InitializeComponent();
            ApplicationView.GetForCurrentView().TryResizeView(new Size(App.DeviceScreenWidth, App.DeviceScreenHeight));
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size(App.DeviceMinimumScreenWidth, App.DeviceMinimumScreenHeight));
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
        }

        private void btnNavBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }

        private void ButtonSelect_Click(object sender, RoutedEventArgs e)
        {
            //object of class
            Lotto row = new Lotto();

            //number of lines variable
            int lines;

            //input from user
            lines = Convert.ToInt32(TextBoxTickets.Text);

            if ((lines > 0) && (lines <= 20))
            {
                //sets up ticket
                TextBlockTickets.Text = "--------------------------------------\n";
                TextBlockTickets.Text = TextBlockTickets.Text + "-                                    -\n";
                TextBlockTickets.Text = TextBlockTickets.Text + "-            Lotto Ticket            -\n";
                TextBlockTickets.Text = TextBlockTickets.Text + "-                                    -\n";
                TextBlockTickets.Text = TextBlockTickets.Text + "--------------------------------------\n";

                for (int i = 0; i < lines; i++)
                {
                    //start of row
                    TextBlockTickets.Text = TextBlockTickets.Text + "-                                    -\n";
                    TextBlockTickets.Text = TextBlockTickets.Text + "-         ";

                    //generate and print row
                    row.SetNumbersToZero();
                    row.GenerateNumbers();
                    row.PrintNumbers(TextBlockTickets);

                    //end of row
                    TextBlockTickets.Text = TextBlockTickets.Text + "         -\n";
                    TextBlockTickets.Text = TextBlockTickets.Text + "-                                    -\n";
                    TextBlockTickets.Text = TextBlockTickets.Text + "--------------------------------------\n";

                }

            }
            else if (lines <= 0)
            {
                TextBlockTickets.Text = "You need to enter a number of tickets you would like generated";
            }
            else
            {
                TextBlockTickets.Text = "You have entered too many tickets\nPlease enter a number between 1 and 20";
            }

        }
    }
}
